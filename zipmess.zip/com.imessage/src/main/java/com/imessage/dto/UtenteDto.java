package com.imessage.dto;

import java.util.List;

import com.imessage.model.Messaggio;

public class UtenteDto {

	private String us_na;
	
	private String emai;
	
	private String pass;
	
	private boolean is_admin;
	
	private List <Messaggio> elenco_utenti;

	public UtenteDto() {
		super();
	}

	public UtenteDto(String us_na, String emai, String pass, boolean is_admin,
			List<Messaggio> elenco_utenti) {
		super();
		this.us_na = us_na;
		this.emai = emai;
		this.pass = pass;
		this.is_admin = is_admin;
	}

	public List<Messaggio> getElenco_utenti() {
		return elenco_utenti;
	}

	public void setElenco_utenti(List<Messaggio> elenco_utenti) {
		this.elenco_utenti = elenco_utenti;
	}

	public String getUs_na() {
		return us_na;
	}

	public void setUs_na(String us_na) {
		this.us_na = us_na;
	}

	public String getEmai() {
		return emai;
	}

	public void setEmai(String emai) {
		this.emai = emai;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public boolean isIs_admin() {
		return is_admin;
	}

	public void setIs_admin(boolean is_admin) {
		this.is_admin = is_admin;
	}
	
	
}
