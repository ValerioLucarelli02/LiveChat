package com.imessage.dto;

import java.time.LocalDate;

import com.imessage.model.Utente;


public class MessaggioDto {

	private LocalDate ms_in;
	private String ms_te;
	private Utente persona;
	
	public MessaggioDto() {
		super();
	}
	public MessaggioDto(LocalDate ms_in, String ms_te) {
		super();
		this.ms_in = ms_in;
		this.ms_te = ms_te;
		this.persona = persona;
	}
	public Utente getPersona() {
		return persona;
	}
	public void setPersona(Utente persona) {
		this.persona = persona;
	}
	public LocalDate getMs_in() {
		return ms_in;
	}
	public void setMs_in(LocalDate ms_in) {
		this.ms_in = ms_in;
	}
	public String getMs_te() {
		return ms_te;
	}
	public void setMs_te(String ms_te) {
		this.ms_te = ms_te;
	}
	
	
}
