package com.imessage.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.imessage.model.Messaggio;


@Repository
public interface MessaggioRepository extends JpaRepository<Messaggio, Integer> {

	public Optional<Messaggio> findById (Integer id);
	
}
