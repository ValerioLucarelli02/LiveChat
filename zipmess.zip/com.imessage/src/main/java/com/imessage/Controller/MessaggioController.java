package com.imessage.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.imessage.dto.MessaggioDto;
import com.imessage.service.MessaggioService;

@RestController
@CrossOrigin(origins = "http://localhost:8080", allowCredentials = "true") //dico a tomcat che altre applicazioni possono accedere al web
@RequestMapping("messagio")
public class MessaggioController {
	@Autowired
	private MessaggioService service;
	
	@PostMapping ("/inserisci")
	public MessaggioDto inserisciMess(@RequestBody MessaggioDto mess) {
		return service.inserisciMess(mess);
		
	}
	@GetMapping("/allMessage")
	public List<MessaggioDto> allMess(){
		return service.listaMess();
		
	}
	{
		
	}

}
