package com.imessage.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.imessage.dto.MessaggioDto;
import com.imessage.model.Messaggio;
import com.imessage.repository.MessaggioRepository;



@Service
public class MessaggioService {
	
	@Autowired
	private MessaggioRepository repo;
	
	@Autowired
	private ModelMapper mapper;
	
	public MessaggioDto inserisciMess(MessaggioDto mess) {
		
		Messaggio mss = mapper.map(mess, Messaggio.class);
		Messaggio nuovoMess;
		try {
			nuovoMess = repo.save(mss);
		} catch (Exception e) {
			return null;
		}
		
		if(nuovoMess.getId() == null) {
			return null;
		}else {
			return mapper.map(nuovoMess, MessaggioDto.class);
		}
		
	}
	
public List <MessaggioDto> listaMess(){
	List<Messaggio> elenco = repo.findAll();
	List<MessaggioDto> elencoDto = new ArrayList<>();
	
	for(Messaggio m:elenco) {
		MessaggioDto mss = mapper.map(m, MessaggioDto.class);
		
		elencoDto.add(mss);
	}
	return elencoDto;
}
}