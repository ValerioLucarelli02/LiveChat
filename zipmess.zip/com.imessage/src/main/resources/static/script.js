const uri = "http://localhost:8080/Imessage";
const urilog = "http://localhost:8080/login";
const log  = "/login";
const reg  = "/signUp";

function inserisci(){
    let us_na = $("#inputus_na").val();
    let emai = $("#inputEmai").val();
    let pass = $("#inputPass").val();

    const utente = {
        us_na: us_na,
        emai: emai,
        pass: pass
    }

    fetch(urilog + reg, {

        method: "POST",
        body: JSON.stringify(utente),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(risultato => risultato.json())
    .then(data => {
        alert("Registrazione effettuata con successo!")
    })
    .catch(errore => alert(errore));


}

function login(){
   // let us_na = $("#logus_na").val();
    let emai = $("#inputEmai").val();
    let pass = $("#logPass").val();

    const utente = {
       // us_na: us_na,
        emai: emai,
        pass: pass
    }

    if (emai === "" || pass === "") {
        return;
    } else {
        alert("entrato prima della fetch");
        fetch(urilog + log, {
    
            method: "POST",
            credentials: "include",
            body: JSON.stringify(utente),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then((risultato) => risultato.json())
        .then((data) => {
            alert("login a buon fine, benvenuto");
           // if(data.stato == "ok"){
                alert("stato ok");
                window.location.replace("./index.html");
           // }
        })
        .catch(errore => alert("login non andato a buon fine"));
    }

}

function stampaUtenti(){

    fetch(uri)
        .then(risultato => risultato.json())
        .then(data => alert("OOOK"))
        .catch(errore => alert("KOOOO"));

}

function modificaUt(varUs){

    $.ajax(
        {
            url: uri + "/" + varus_na,
            type: "GET",
            success: function(risultato){
                console.log(risultato)
                $("#updateus_na").val(risultato.us_na)
                $("#updateEmai").val(risultato.emai)
                $("#updatePass").val(risultato.pass)
                



                
            },
            error: function(errore){
                alert("errore1")
            }
        }
    );

}

function effettuaModificaUt(varUs){
    let user = $("#updateUser").val();
    let emai = $("#updateEmai").val();
    let pass = $("#updatePass").val();

    const utente = {
        user: user,
        emai: emai,
        pass: pass
    }

    fetch(uri + "/" + varUs, {

        method: "GET",
        body: JSON.stringify(utente),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(risultato => risultato.json())
    .then(data => {
        alert(data)
    })
    .catch(errore => alert(errore));


}


// fetch(uri).then(risultato => risultato.json())
// .then(data => console.log(data))
// .catch(errore => alert("Errore!"));

$(document).ready(
    function(){
    
        $("#pulsanteSalva").click(() => {
            inserisci();
        })

        $("#pulsanteLog").click(() => {
            login();
        })

        stampa();

    }
)